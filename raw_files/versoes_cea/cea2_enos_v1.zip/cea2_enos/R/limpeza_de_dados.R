library(openxlsx)
library(dplyr)
library(tidyr)

anos <- 1950:2010
meses <- c('Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez')

arq_pluviometros <- 'dados_brutos/planilha_precipitação_piquiri.xlsx'
arq_outros <- 'dados_brutos/dados_marcio_doutorado.xlsx'

pluviometros <- arq_pluviometros %>% 
  loadWorkbook %>% 
  sheets

ler_planilhas <- function(p, arq = arq_pluviometros, comeco, l, c){
  d <- read.xlsx(arq, p, startRow = comeco, colNames = T)[l, c] %>% 
    gather(key = 'Mes', value = 'Valor', -Ano) %>% 
    mutate(pluviometro = p,
           Valor = gsub('\\*','',Valor),
           Valor = as.numeric(gsub('\\,','.',Valor)),
           Mes = factor(Mes, meses))
  return(d)
}

pluviometros <- plyr::ldply(pluviometros, ler_planilhas, comeco = 15, l = 1:35, c = 1:13)

bacias <- c('Guampará',
            'Porto Guarani',
            'Santa Maria')

vazao <-  read.xlsx(arq_outros, 2, startRow = 1) %>% 
  mutate(bacia = rep(bacias, each = 37)) %>% 
  setNames(c((.)[1,-ncol(.)],'Bacia')) %>% 
  gather(key = 'Mes', value = 'Valor', -Ano, -Bacia) %>% 
  mutate(Valor = gsub('\\*','',Valor),
         Valor = gsub('\\,','.',Valor)) %>% 
  filter(Ano %in% anos,
         Mes %in% meses) %>% 
  mutate(Valor = as.numeric(Valor),
         Mes = factor(Mes, meses))

ios <- read.xlsx(arq_outros, 3) %>% 
  gather(key = 'Mes', value = 'Valor', -Ano) %>% 
  mutate(Valor = gsub('\\*','',Valor),
         Valor = as.numeric(gsub('\\,','.',Valor)),
         Mes = factor(Mes, meses)) %>% 
  filter(!is.na(Valor))

saveRDS(vazao, 'dados/vazao.rds')
saveRDS(ios, 'dados/ios.rds')
saveRDS(pluviometros, 'dados/pluviometros.rds')

write.xlsx(vazao, 'dados/vazao.xlsx')
write.xlsx(ios, 'dados/ios.xlsx')
write.xlsx(pluviometros, 'dados/pluviometros.xlsx')
