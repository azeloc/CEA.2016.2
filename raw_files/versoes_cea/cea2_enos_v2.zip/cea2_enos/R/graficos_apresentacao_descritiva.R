library(dplyr)
library(ggplot2)
library(magrittr)
library(lubridate)

completo %<>% 
  arrange(data) 

completo %>% 
  group_by(pluviometro, mes) %>% 
  summarise(Precipitacao = mean(Precipitacao, na.rm = T)) %>% 
  ggplot(aes(x = mes, y = Precipitacao))+
  geom_line()+
  facet_wrap(~pluviometro, ncol = 6)+
  theme_bw()

completo %>% 
  group_by(Bacia, mes) %>% 
  summarise(
    v_10 = quantile(Vazao, 0.1, na.rm = T),
    v_90 = quantile(Vazao, 0.9, na.rm = T),
    Vazao = mean(Vazao, na.rm = T)) %>% 
  ggplot(aes(x = mes, y = Vazao))+
  geom_point()+
  geom_ribbon(aes(ymin = v_10, ymax = v_90), alpha = 0.1, fill = 'black')+
  facet_wrap(~Bacia, ncol = 2, scales = 'free_y')+
  theme_bw()

completo %>% 
  group_by(pluviometro, estacao) %>% 
  summarise(Precipitacao = mean(Precipitacao, na.rm = T)) %>% 
  ggplot(aes(x = estacao, y = Precipitacao))+
  geom_line()+
  facet_wrap(~pluviometro, ncol = 6)+
  theme_bw()

vazao <- completo %>% 
  filter(Bacia == 'Santa Maria') %>% 
  group_by(data, Evento) %>% 
  summarise_each(funs(mean(., na.rm = T)), IOS, Vazao, Precipitacao)

vazao %>% 
  mutate(mes = month(data)) %>% 
  ggplot(aes(x = Precipitacao, y = Vazao, group = mes))+
  geom_point()+
  geom_smooth(method = 'lm', alpha = 0)+
#  facet_wrap(~mes)
  theme_bw()

data_fit <- vazao %>% 
  ungroup() %>% 
  mutate(l_IOS = lag(IOS,1),
         l_Precipitacao = lag(Precipitacao,1),
         l2_Precipitacao = lag(Precipitacao,2),
         Mes = as.factor(month(data)),
         Evento = ifelse(Evento == 'Nada', 'a1 Nada', Evento))

X <- data_fit %>% 
  with(model.matrix(~ Precipitacao + l_Precipitacao +
                    l2_Precipitacao + Evento + Mes
                    + IOS - 1))

# fit_lm <- lm(Vazao ~ Mes +
#                IOS +
#                l_IOS +
#                Precipitacao - 1, data_fit)

fit <- auto.arima(x = vazao$Vazao[-c(1,2)], xreg = X[,-4])

vazao %>% 
ungroup() %>% 
mutate(decenio = cut(year(data), 4, labels = F),
       std_IOS = (IOS - mean(IOS))/sd(IOS)) %>% 
ggplot(aes(x = data, y = Vazao))+
 geom_line(alpha = 0.2, color = 'lightgray')+
  geom_point(aes(color = IOS, size = abs(IOS)))+
  scale_color_gradient2(mid = 'gray',
                        low = 'red',
                        high = 'blue',
                        midpoint = -0.2) +
  scale_size(range = c(0,3)) +
  theme_bw() +
  facet_wrap(~decenio, scales = 'free_x')

vazao %>% 
  ungroup() %>% 
  mutate(decenio = cut(year(data), 4, labels = F),
         std_IOS = (IOS - mean(IOS))/sd(IOS)) %>% 
  ggplot(aes(x = data, y = Vazao))+
  geom_line(alpha = 0.2, color = 'lightgray')+
  geom_point(aes(color = IOS, size = abs(IOS)))+
  scale_color_gradient2(mid = 'gray',
                        low = 'red',
                        high = 'blue',
                        midpoint = -0.2) +
  scale_size(range = c(0,3,4)) +
  theme_bw() +
  facet_wrap(~decenio, scales = 'free_x')

vazao %>% 
  ungroup() %>% 
  mutate(decenio = cut(year(data), 4, labels = F),
         std_IOS = (IOS - mean(IOS))/sd(IOS),
         IOS = ifelse(IOS >= 0, 0, IOS)) %>% 
  ggplot(aes(x = data, y = Vazao))+
  geom_line(alpha = 0.2, color = 'lightgray')+
  geom_point(aes(color = IOS, size = abs(IOS)))+
  scale_color_gradient2(mid = 'gray',
                        low = 'red',
                        high = 'blue',
                        midpoint = -0.2) +
  scale_size(range = c(0,3)) +
  theme_bw() +
  facet_wrap(~decenio, scales = 'free_x')


vazao %>% 
  ungroup() %>% 
  mutate(l_IOS = lag(IOS, 1),
         agrupar = ifelse(l_IOS < -8, 1, ifelse(l_IOS > 8, 0, 2))) %>% 
       #  prec_tercil = cut(Precipitacao, breaks = quantile(Precipitacao, c(0,0.3,0.6)), labels = F)
  ggplot(aes(x = l_IOS, y = Vazao, group = agrupar)) +
  geom_point()+
  #facet_grid(~Evento, scales = 'free')+
  theme_bw()+
  geom_smooth(method = 'lm', alpha = 0)+
  geom_vline(xintercept = -10, col = 'red')+
  geom_vline(xintercept = 10, col = 'red')+
  geom_hline(yintercept = 1000, col = 'blue')
