library(ggplot2)
library(dplyr)

dados <- readRDS('dados/dados_exemplo.rds')

#Código Figura 1

ggplot(dados, aes(x = x, y = y))+
  geom_point()+
  geom_smooth(alpha = 0, method = 'lm')+
  geom_smooth(alpha = 0, color = 'red', linetype = 2)+
  theme_bw()+
  ggtitle('X contra Y')+
  xlab('X')+
  ylab('Y')

ggsave('figuras/figura_1.png', device = 'png')

#Tabela 1
dados %>% 
  summarise_each(funs(
    media = round(mean(.),2), 
    dp = round(sd(.),2))) %>% 
  openxlsx::write.xlsx('tabelas/tabela_1.xlsx')

