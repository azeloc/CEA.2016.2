library(openxlsx)
library(dplyr)
library(tidyr)
library(lubridate)

anos <- 1950:2010
meses <- c('Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez')

arq_pluviometros <- 'dados_brutos/planilha_precipitação_piquiri.xlsx'
arq_outros <- 'dados_brutos/dados_marcio_doutorado.xlsx'

pluviometros <- arq_pluviometros %>% 
  loadWorkbook %>% 
  sheets

ler_planilhas <- function(p, arq, comeco, l, c){
  d <- read.xlsx(arq, p, startRow = comeco, colNames = T)[l, c] %>% 
    gather(key = 'Mes', value = 'Valor', -Ano) %>% 
    mutate(pluviometro = p,
           Valor = gsub('\\*','',Valor),
           Valor = as.numeric(gsub('\\,','.',Valor)),
           Mes = factor(Mes, meses),
           mes = as.numeric(Mes),
           estacao = mes %% 4,
           Estacao = ifelse(estacao == 1, 'Verão', ifelse(estacao == 2, 'Outono', ifelse(estacao == 3, 'Inverno', 'Primavera'))))
  return(d)
}

ler_pra_detectar_coisas_estranhas <- function(p, arq, comeco, l, c){
  d <- read.xlsx(arq, p, startRow = comeco, colNames = T)[l, c] %>% 
    gather(key = 'Mes', value = 'Valor', -Ano) %>% 
    mutate(pluviometro = p,
           estranho = grepl('[*,]',Valor),
           #Valor = gsub('\\*','',Valor),
           #Valor = as.numeric(gsub('\\,','.',Valor)),
           Mes = factor(Mes, meses),
           mes = as.numeric(Mes),
           estacao = mes %% 4,
           Estacao = ifelse(estacao == 1, 'Verão', ifelse(estacao == 2, 'Outono', ifelse(estacao == 3, 'Inverno', 'Primavera'))))
  return(d)
}

pluviometros_2 <- plyr::ldply(pluviometros, ler_pra_detectar_coisas_estranhas, arq = arq_pluviometros, comeco = 15, l = 1:35, c = 1:13)
pluviometros <- plyr::ldply(pluviometros, ler_planilhas, arq = arq_pluviometros, comeco = 15, l = 1:35, c = 1:13)

bacias <- c('Guampará',
            'Porto Guarani',
            'Santa Maria')

vazao <-  read.xlsx(arq_outros, 2, startRow = 1) %>% 
  mutate(bacia = rep(bacias, each = 37)) %>% 
  setNames(c((.)[1,-ncol(.)],'Bacia')) %>% 
  gather(key = 'Mes', value = 'Valor', -Ano, -Bacia) %>% 
  mutate(Valor = gsub('\\*','',Valor),
         Valor = gsub('\\,','.',Valor)) %>% 
  filter(Ano %in% anos,
         Mes %in% meses) %>% 
  mutate(Valor = as.numeric(Valor),
         Mes = factor(Mes, meses),
         mes = as.numeric(Mes),
         estacao = mes %% 4,
         Estacao = ifelse(estacao == 1, 'Verão', ifelse(estacao == 2, 'Outono', ifelse(estacao == 3, 'Inverno', 'Primavera'))))


ios <- read.xlsx(arq_outros, 3) %>% 
  gather(key = 'Mes', value = 'Valor', -Ano) %>% 
  mutate(Valor = gsub('\\*','',Valor),
         Valor = as.numeric(gsub('\\,','.',Valor)),
         Mes = factor(Mes, meses),
         Evento = ifelse(Valor > 8, 'La Niña', ifelse(Valor < -8, 'El Niño', 'Nada'))) %>% 
  filter(!is.na(Valor))

completo <- inner_join(ios,vazao, by = c('Ano','Mes')) %>% 
  rename(IOS = Valor.x, Vazao = Valor.y) %>% 
  inner_join(pluviometros, by = c('Ano','Mes','mes','estacao','Estacao')) %>% 
  rename(Precipitacao = Valor) %>% 
  mutate(data = dmy(paste('01',mes,Ano)))

saveRDS(vazao, 'dados/vazao.rds')
saveRDS(ios, 'dados/ios.rds')
saveRDS(pluviometros, 'dados/pluviometros.rds')
saveRDS(completo,'dados/completo.rds')

write.xlsx(vazao, 'dados/vazao.xlsx')
write.xlsx(ios, 'dados/ios.xlsx')
write.xlsx(pluviometros, 'dados/pluviometros.xlsx')
write.xlsx(completo,'dados/completo.xlsx')
