library(dplyr)
library(ggplot2)
library(lubridate)
library(forecast)
#install.packages('ggfortify')
library(ggfortify)

completo <- readRDS('dados/completo.rds')

completo %>% 
  distinct(Ano,Mes,Bacia, .keep_all = T) %>% 
  ggplot(aes(x = data, y = Vazao, colour = Bacia))+
  geom_line()+
  facet_grid(Bacia~., scale = 'free_y')+
  theme_bw()+

completo %>% 
  distinct(Ano, Mes, pluviometro, .keep_all = T) %>% 
  mutate(pluviometro = factor(pluviometro)) %>% 
  ggplot(aes(x = Mes, y = Precipitacao))+
  geom_boxplot()+
  facet_wrap(~pluviometro)+
  theme_bw()

completo %>% 
  distinct(Ano, Mes, pluviometro, .keep_all = T) %>% 
  mutate(pluviometro = factor(pluviometro)) %>% 
  ggplot(aes(x = Estacao, y = Precipitacao), stat = 'sum')+
  geom_boxplot()+
  facet_wrap(~pluviometro)+
  theme_bw()

completo %>% 
  distinct(Ano, Mes, pluviometro, .keep_all = T) %>% 
  mutate(pluviometro = factor(pluviometro)) %>% 
  group_by(estacao, pluviometro) %>% 
  summarise(Precipitacao = sum(Precipitacao)) %>% 
  ggplot(aes(x = estacao, y = Precipitacao, colour = pluviometro))+
#  geom_boxplot()+
  geom_line()+
#  facet_wrap(~pluviometro)+
  theme_bw()

completo %>% 
  distinct(Ano, Mes, pluviometro, .keep_all = T) %>% 
  mutate(pluviometro = factor(pluviometro)) %>% 
  group_by(mes, pluviometro) %>% 
  summarise(
    Prep_max = quantile(Precipitacao, 0.9, na.rm = T),
    Prep_min = quantile(Precipitacao, 0.1, na.rm = T),
    Precipitacao = mean(Precipitacao, na.rm = T)) %>% 
  ggplot(aes(x = mes, y = Precipitacao, ymax = Prep_max, ymin = Prep_min))+
  #  geom_boxplot()+
  geom_line()+
  geom_ribbon(alpha = 0.15)+
  facet_wrap(~pluviometro)+
  scale_x_continuous(breaks = 1:12)+
  theme_bw()

completo %>% 
  distinct(Ano,Mes,Bacia, .keep_all = T) %>% 
  ggplot(aes(x = IOS, y = Vazao, colour = Bacia))+
  geom_smooth(alpha = 0, method = 'lm')+
  geom_point()+
  theme_bw()+
  facet_wrap(Bacia~Evento, scales = 'free')

completo %>% 
  distinct(Ano,Mes,Bacia, .keep_all = T) %>% 
  filter(Ano %in% as.character(1997:1999)) %>% 
  ggplot(aes(x = IOS, y = Vazao, colour = Bacia))+
  geom_smooth(alpha = 0, method = 'lm')+
  geom_point()+
  theme_bw()+
  facet_wrap(Bacia~Evento, scales = 'free')

completo %>% 
  distinct(Ano,Mes,Bacia, .keep_all = T) %>% 
  filter(data >= '1997-03-01', data <= '1999-04-01') %>% 
  group_by(Evento, Bacia) %>%  
  summarise(r = cor(IOS,Vazao, method = 'pearson'))

completo %>% 
  distinct(Ano,Mes,Bacia, .keep_all = T) %>% 
  filter(data >= '1997-03-01', data <= '1999-04-01') %>% 
  group_by(Bacia) %>% 
  arrange(data) %>% 
  mutate(L_IOS = lag(IOS),
         L_Evento = lag(Evento)) %>% 
  filter(L_Evento != 'Nada', !is.na(L_Evento)) %>% 
  #  summarise(r = cor(IOS,Vazao, method = 'pearson')) %>% 
  ggplot(aes(x = L_IOS, y = Vazao, colour = Bacia))+
  geom_smooth(alpha = 0, method = 'lm')+
  geom_point()+
  theme_bw()+
  theme(legend.position = 'bottom')+
  facet_grid(Bacia~L_Evento, scales = 'free')

completo %>% 
  distinct(Ano,Mes,Bacia, .keep_all = T) %>% 
  filter(data >= '1997-03-01', data <= '1999-04-01') %>% 
  group_by(Bacia) %>%  
  arrange(data) %>% 
  mutate(L_IOS = lag(IOS),
         L_Evento = lag(Evento)) %>% 
  filter(L_Evento != 'Nada', !is.na(L_Evento)) %>% 
  group_by(Bacia,L_Evento) %>% 
  summarise(r = cor(L_IOS, Vazao, use = 'complete.obs'))

vazao_ios %>% 
  ggplot(aes(x = ios, y = vazao, col = Bacia))+
  geom_point() +
  facet_wrap(~Bacia, scales = 'free') +
  geom_smooth(alpha = 0) + 
  theme_bw()

vazao_ios %>% 
  distinct(Ano,Mes,Bacia, .keep_all = T) %>% 
  group_by(Ano, Bacia) %>% 
  summarise(ios = sum(ios),
            vazao = sum(vazao)) %>% 
  ggplot(aes(x = ios, y = vazao, col = Bacia))+
  geom_point() +
  facet_wrap(~Bacia, scales = 'free') +
  geom_smooth(alpha = 0) + 
  theme_bw()

vazao_ios %>% 
  filter(!is.na(vazao)) %>% 
  distinct(Ano,Mes,Bacia, .keep_all = T) %>% 
  group_by(Bacia) %>% 
  arrange(data) %>% 
  do(ccf = Ccf(.$ios, .$vazao)) -> ccfs

vazao_ios %>% 
  filter(!is.na(vazao)) %>% 
  distinct(Ano,Mes,Bacia, .keep_all = T) %>% 
  group_by(Bacia) %>% 
  arrange(data) %>% 
  do(ccf = Ccf(.$ios, .$vazao)) -> ccfs


vazao_ios %>% 
  filter(!is.na(vazao)) %>% 
  distinct(Ano,Mes,Bacia, .keep_all = T) %>% 
  group_by(Bacia) %>% 
  arrange(data) %>% 
  do(ios = ts(.$ios, frequency = 12),
     vazao = ts(.$vazao, frequency = 12)) -> series

#Ccf entre IOS e Vazao em Guampará 
ccfs$ccf[1] %>% 
  autoplot + 
  theme_bw() + 
  xlab('Delay') + 
  ylab('Correlação entre\nIOS e Vazao com Delay') + 
  theme(axis.title.y = element_text(angle = 0))

#Ccf entre IOS e Vazao em Porto Guarani
ccfs$ccf[2] %>% 
  autoplot + 
  theme_bw() + 
  xlab('Delay') + 
  ylab('Correlação entre\nIOS e Vazao com Delay') + 
  theme(axis.title.y = element_text(angle = 0))

#Ccf entre IOS e Vazao em Santa Maria
ccfs$ccf[3] %>% 
  autoplot + 
  theme_bw() + 
  xlab('Delay') + 
  ylab('Correlação entre\nIOS e Vazao com Delay') + 
  theme(axis.title.y = element_text(angle = 0))

vazao_ios %>% 
  group_by(pluviometro, Ano) %>% 
  arrange(data) %>% 
  mutate(cum_prop = cumsum(chuva)/sum(chuva)) %>% 
  ggplot(aes(x = Mes, y = cum_prop, colour = Ano))+
  geom_point()+
  geom_smooth(aes(group = pluviometro), alpha = 0)+
  facet_wrap(~pluviometro)
